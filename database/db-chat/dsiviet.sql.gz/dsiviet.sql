-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mar 13 Décembre 2016 à 08:35
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `dsiviet`
--

-- --------------------------------------------------------

--
-- Structure de la table `ads`
--

CREATE TABLE IF NOT EXISTS `ads` (
  `ads_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `code` text NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`ads_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `cate_new_parent`
--

CREATE TABLE IF NOT EXISTS `cate_new_parent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` varchar(50) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `publish` tinyint(7) NOT NULL,
  `link` varchar(255) NOT NULL,
  `parent_id` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=106 ;

--
-- Contenu de la table `cate_new_parent`
--

INSERT INTO `cate_new_parent` (`id`, `id_category`, `Name`, `publish`, `link`, `parent_id`) VALUES
(17, '1', 'Tin 24/7', 1, 'tttth', 0),
(18, '2', 'Bất động sản', 1, '', 1),
(19, '3', 'Biệt thự', 1, '', 1),
(20, '4', 'Cao ốc văn phòng', 1, '', 1),
(21, '5', 'Khu dân cư', 1, '', 1),
(22, '6', 'Thể thao', 1, 't-t', 0),
(23, '7', 'Thị trường - Tiêu dùng', 1, '', 0),
(24, '8', 'Công nghệ thông tin', 1, '', 0),
(25, '9', 'Dự án bất động sản', 1, '', 0),
(26, '10', 'Phong thủy địa ốc', 1, '', 0),
(27, '11', 'Môi trường đầu tư', 1, '', 1),
(28, '12', 'Thông tin bất động sản', 1, '', 1),
(29, '13', 'Công nghệ - Tin học', 1, '', 0),
(30, '14', 'Điện thoại di động', 1, '', 0),
(31, '15', 'Nhà hàng', 1, '', 0),
(32, '16', 'Khách sạn', 1, '', 0),
(33, '17', 'Quán bar', 1, '', 0),
(34, '18', 'Du lịch', 1, 'ttdulich', 0),
(35, '19', 'Trung tâm nghỉ dưỡng', 1, '', 0),
(36, '20', 'Khu vui chơi - giải trí', 1, '', 0),
(37, '21', 'Thủ công mỹ nghệ', 1, '', 0),
(38, '22', 'Lúa gạo', 1, '', 0),
(39, '23', 'Cafe', 1, '', 0),
(40, '24', 'Trà', 1, '', 0),
(41, '25', 'CaCao', 1, '', 0),
(42, '26', 'Thủy sản', 1, '', 0),
(43, '27', 'Trung tâm mua sắm', 1, '', 0),
(44, '28', 'Đầu tư', 1, '', 0),
(45, '29', 'Giá cả', 1, '', 0),
(46, '30', 'Xuất nhập khẩu', 1, '', 0),
(47, '31', 'Chính sách thuế', 1, '', 0),
(48, '32', 'Máy nghe nhạc', 1, '', 0),
(49, '33', 'Máy ảnh - Camera số', 1, '', 0),
(50, '34', 'Sản phẩm điện tử khác', 1, '', 0),
(51, '35', 'Laptop giá rẻ', 1, '', 0),
(52, '36', 'Máy tính sách tay', 1, '', 0),
(53, '37', 'Máy tính để bàn', 1, '', 0),
(54, '38', 'Quảng cáo trực tuyến', 1, '', 0),
(55, '39', 'Phần mềm CNTT', 1, '', 0),
(56, '40', 'Tin học văn phòng', 1, '', 0),
(57, '41', 'Máy in/Phụ kiện', 1, '', 0),
(58, '42', 'Thủ thuật - Tiện ích', 1, '', 0),
(59, '43', 'Sản phẩm mới', 1, '', 0),
(60, '44', 'Virut', 1, '', 0),
(61, '45', 'Bình luận', 1, 'sk-bl', 0),
(62, '46', 'Bóng đá cười', 1, 'bdc', 0),
(63, '47', 'Việt Nam', 1, 'bdvn', 0),
(64, '48', 'Ngoại hạng anh', 1, 'bdnha', 0),
(65, '49', 'Bóng đá Ý', 1, 'bdy', 0),
(66, '50', 'Tây Ban Nha', 1, 'bdtbn', 0),
(67, '51', 'Ô tô - Xe máy', 1, '', 0),
(68, '52', 'Xe xịn', 1, '', 0),
(69, '53', 'Thuê xe HCM', 1, '', 0),
(70, '54', 'Thuê xe HN', 1, '', 0),
(71, '55', 'Xi măng', 1, '', 0),
(72, '56', 'Sắt thép', 1, '', 0),
(73, '57', 'Môi giới', 1, '', 0),
(74, '58', 'Phát triển nhanh', 1, '', 0),
(75, '59', 'Quản lý kinh doanh', 1, '', 0),
(76, '60', 'Báo cáo thuế', 1, '', 0),
(77, '61', 'Cho thuê tài chính', 1, '', 0),
(78, '62', 'Ngân hàng', 1, '', 0),
(79, '63', 'Ngành bảo hiểm', 1, '', 0),
(80, '64', 'Chuyên chở hàng hóa', 1, '', 0),
(81, '65', 'Giao thông vận tải', 1, '', 0),
(82, '66', 'Nhu cầu mua', 1, '', 0),
(83, '67', 'Nhu cầu bán', 1, '', 0),
(84, '68', 'Cho thuê lại', 1, '', 0),
(85, '69', 'Tìm kiếm BĐS', 1, '', 0),
(86, '70', 'Tìm đối tác', 1, '', 0),
(87, '71', 'Âm nhạc', 1, '', 0),
(88, '72', 'Truyện cười', 1, '', 0),
(89, '73', 'Điển ảnh', 1, '', 0),
(90, '74', 'Game', 1, '', 0),
(91, '75', 'Các khu căn hộ', 1, '', 0),
(92, '76', 'Khu công nghiệp', 1, '', 0),
(93, '77', 'Khu chế xuất', 1, '', 0),
(94, '78', 'Đất đai', 1, '', 0),
(95, '79', 'Nhà xưởng', 1, '', 0),
(96, '80', 'Đất dự án', 1, '', 0),
(97, '81', 'Quản lý bất động sản', 1, '', 0),
(98, '82', 'Thương mại', 1, '', 0),
(99, '83', 'Hi - Tech', 1, '', 0),
(100, '84', 'Giao dịch địa ốc', 1, '', 0),
(101, '85', 'Giải trí', 1, '', 0),
(102, '86', 'Rao vặt', 1, '', 0),
(103, '87', 'Bóng đá', 1, 'bd', 0);

-- --------------------------------------------------------

--
-- Structure de la table `conversations`
--

CREATE TABLE IF NOT EXISTS `conversations` (
  `conversation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `last_message_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`conversation_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=2 ;

--
-- Contenu de la table `conversations`
--

INSERT INTO `conversations` (`conversation_id`, `last_message_id`) VALUES
(1, 5);

-- --------------------------------------------------------

--
-- Structure de la table `conversations_messages`
--

CREATE TABLE IF NOT EXISTS `conversations_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=6 ;

--
-- Contenu de la table `conversations_messages`
--

INSERT INTO `conversations_messages` (`message_id`, `conversation_id`, `user_id`, `message`, `image`, `time`) VALUES
(1, 1, 1, 'dfasdfasd', '', '2016-12-07 10:11:48'),
(2, 1, 2, 'bgcfjiasdhfias', '', '2016-12-07 10:12:00'),
(3, 1, 1, 'adsfdasf', '', '2016-12-07 10:12:13'),
(4, 1, 1, '^_^ ', '', '2016-12-07 10:12:17'),
(5, 1, 2, '&agrave;dsfasd', '', '2016-12-07 10:13:51');

-- --------------------------------------------------------

--
-- Structure de la table `conversations_users`
--

CREATE TABLE IF NOT EXISTS `conversations_users` (
  `conversation_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `seen` enum('0','1') NOT NULL DEFAULT '0',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  UNIQUE KEY `conversation_id_user_id` (`conversation_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Contenu de la table `conversations_users`
--

INSERT INTO `conversations_users` (`conversation_id`, `user_id`, `seen`, `deleted`) VALUES
(1, 1, '1', '0'),
(1, 2, '1', '0');

-- --------------------------------------------------------

--
-- Structure de la table `followings`
--

CREATE TABLE IF NOT EXISTS `followings` (
  `user_id` int(10) unsigned NOT NULL,
  `following_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `user_id_following_id` (`user_id`,`following_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Contenu de la table `followings`
--

INSERT INTO `followings` (`user_id`, `following_id`) VALUES
(2, 1);

-- --------------------------------------------------------

--
-- Structure de la table `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_one_id` int(10) unsigned NOT NULL,
  `user_two_id` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_one_id_user_two_id` (`user_one_id`,`user_two_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `friends`
--

INSERT INTO `friends` (`id`, `user_one_id`, `user_two_id`, `status`) VALUES
(1, 2, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `games`
--

CREATE TABLE IF NOT EXISTS `games` (
  `game_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET latin1 NOT NULL,
  `description` text CHARACTER SET latin1 NOT NULL,
  `source` text CHARACTER SET latin1 NOT NULL,
  `thumbnail` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `group_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_admin` int(10) unsigned NOT NULL,
  `group_name` varchar(50) NOT NULL,
  `group_title` varchar(255) NOT NULL,
  `group_picture` varchar(255) NOT NULL,
  `group_cover` varchar(255) NOT NULL,
  `group_description` text NOT NULL,
  `group_members` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `username` (`group_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `groups_members`
--

CREATE TABLE IF NOT EXISTS `groups_members` (
  `group_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `group_id_user_id` (`group_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `to_user_id` int(10) unsigned NOT NULL,
  `from_user_id` int(10) unsigned NOT NULL,
  `action` varchar(50) NOT NULL,
  `node_type` varchar(50) NOT NULL,
  `node_url` varchar(255) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `seen` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`notification_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `to_user_id`, `from_user_id`, `action`, `node_type`, `node_url`, `time`, `seen`) VALUES
(1, 1, 2, 'follow', '', '', '2016-12-07 10:11:31', '1'),
(2, 2, 1, 'friend', '', '', '2016-12-07 10:11:40', '1');

-- --------------------------------------------------------

--
-- Structure de la table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `page_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_admin` int(10) unsigned NOT NULL,
  `page_category` int(10) unsigned NOT NULL,
  `page_name` varchar(50) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_picture` varchar(255) NOT NULL,
  `page_cover` varchar(255) NOT NULL,
  `page_description` text NOT NULL,
  `page_verified` enum('0','1') NOT NULL DEFAULT '0',
  `page_likes` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `username` (`page_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `pages_categories`
--

CREATE TABLE IF NOT EXISTS `pages_categories` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `pages_categories`
--

INSERT INTO `pages_categories` (`category_id`, `category_name`) VALUES
(1, 'Service'),
(2, 'Musician/Band'),
(3, 'Brand or Product'),
(4, 'Company, Organization or Institution'),
(5, 'Artist, Public figure'),
(6, 'Entertainment'),
(7, 'Cause or Community');

-- --------------------------------------------------------

--
-- Structure de la table `pages_likes`
--

CREATE TABLE IF NOT EXISTS `pages_likes` (
  `page_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `page_id_user_id` (`page_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `user_type` enum('user','page') NOT NULL,
  `in_group` enum('0','1') NOT NULL DEFAULT '0',
  `group_id` int(10) unsigned DEFAULT NULL,
  `post_type` varchar(50) NOT NULL,
  `origin_id` int(10) unsigned DEFAULT NULL,
  `time` datetime NOT NULL,
  `location` varchar(50) NOT NULL,
  `privacy` enum('friends','public') NOT NULL,
  `text` longtext NOT NULL,
  `likes` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `shares` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `posts`
--

INSERT INTO `posts` (`post_id`, `user_id`, `user_type`, `in_group`, `group_id`, `post_type`, `origin_id`, `time`, `location`, `privacy`, `text`, `likes`, `comments`, `shares`) VALUES
(5, 2, 'user', '0', 0, 'photos', NULL, '2016-12-07 10:26:02', 'dfdsfsda dsf sdafasd', 'friends', 'fdasfasdfasdf', 0, 0, 0),
(3, 1, 'user', '0', 0, 'photos', NULL, '2016-12-07 10:20:53', 'hcm', 'public', 'fasdfasdf ;( ', 0, 1, 1),
(4, 1, 'user', '0', NULL, 'shared', 3, '2016-12-07 10:21:07', '', 'public', '', 0, 0, 0),
(6, 1, 'user', '0', 0, '', NULL, '2016-12-12 07:41:35', 'Hcm', 'friends', 'fsadf', 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `posts_comments`
--

CREATE TABLE IF NOT EXISTS `posts_comments` (
  `comment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `node_id` int(10) unsigned NOT NULL,
  `node_type` enum('post','photo') NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_type` enum('user','page') NOT NULL,
  `text` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `time` datetime NOT NULL,
  `likes` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `posts_comments`
--

INSERT INTO `posts_comments` (`comment_id`, `node_id`, `node_type`, `user_id`, `user_type`, `text`, `image`, `time`, `likes`) VALUES
(1, 3, 'post', 1, 'user', 'fdsafsdf', '', '2016-12-07 10:21:18', 0);

-- --------------------------------------------------------

--
-- Structure de la table `posts_comments_likes`
--

CREATE TABLE IF NOT EXISTS `posts_comments_likes` (
  `user_id` int(10) unsigned NOT NULL,
  `comment_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `comment_id_user_id` (`comment_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Structure de la table `posts_hidden`
--

CREATE TABLE IF NOT EXISTS `posts_hidden` (
  `user_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `post_id_user_id` (`post_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Structure de la table `posts_likes`
--

CREATE TABLE IF NOT EXISTS `posts_likes` (
  `user_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `post_id_user_id` (`post_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `posts_links`
--

CREATE TABLE IF NOT EXISTS `posts_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `source_url` tinytext NOT NULL,
  `source_host` varchar(255) NOT NULL,
  `source_title` varchar(255) NOT NULL,
  `source_text` text NOT NULL,
  `source_thumbnail` varchar(255) NOT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `posts_media`
--

CREATE TABLE IF NOT EXISTS `posts_media` (
  `media_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) NOT NULL,
  `media_type` enum('youtube','vimeo','soundcloud') NOT NULL,
  `source_uid` varchar(255) NOT NULL,
  `source_url` text NOT NULL,
  `source_title` varchar(255) DEFAULT NULL,
  `source_text` text,
  PRIMARY KEY (`media_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `posts_photos`
--

CREATE TABLE IF NOT EXISTS `posts_photos` (
  `photo_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `source` varchar(255) NOT NULL,
  `likes` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`photo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `posts_photos`
--

INSERT INTO `posts_photos` (`photo_id`, `post_id`, `source`, `likes`, `comments`) VALUES
(1, 3, 'sngine_fd0113b813f9c60d324beb96ac1efdd6.jpg', 0, 0),
(2, 5, 'sngine_dcf789049429893e8de83abc8e35ea9d.jpg', 0, 0),
(3, 5, 'sngine_b6e815e37e617dba11d204aecd300392.jpg', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `posts_photos_likes`
--

CREATE TABLE IF NOT EXISTS `posts_photos_likes` (
  `user_id` int(10) unsigned NOT NULL,
  `photo_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `user_id_photo_id` (`user_id`,`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

-- --------------------------------------------------------

--
-- Structure de la table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `report_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `node_id` int(10) NOT NULL,
  `node_type` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `static_pages`
--

CREATE TABLE IF NOT EXISTS `static_pages` (
  `page_id` int(10) NOT NULL AUTO_INCREMENT,
  `page_url` varchar(50) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_text` text NOT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `page_url` (`page_url`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `static_pages`
--

INSERT INTO `static_pages` (`page_id`, `page_url`, `page_title`, `page_text`) VALUES
(1, 'about', 'About', '&lt;p&gt;\r\n                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;\r\n            &lt;h3 class=&quot;text-info&quot;&gt;\r\n                Big Title\r\n            &lt;/h3&gt;\r\n            &lt;p&gt;\r\n                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;\r\n            &lt;h3 class=&quot;text-info&quot;&gt;\r\n                Big Title\r\n            &lt;/h3&gt;\r\n            &lt;p&gt;\r\n               Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;'),
(2, 'terms', 'Terms', '&lt;p&gt;\r\n                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;\r\n            &lt;h3 class=&quot;text-info&quot;&gt;\r\n                Big Title\r\n            &lt;/h3&gt;\r\n            &lt;p&gt;\r\n                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;\r\n            &lt;h3 class=&quot;text-info&quot;&gt;\r\n                Big Title\r\n            &lt;/h3&gt;\r\n            &lt;p&gt;\r\n               Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;'),
(3, 'privacy', 'Privacy', '&lt;p&gt;\r\n                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;\r\n            &lt;h3 class=&quot;text-info&quot;&gt;\r\n                Big Title\r\n            &lt;/h3&gt;\r\n            &lt;p&gt;\r\n                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;\r\n            &lt;h3 class=&quot;text-info&quot;&gt;\r\n                Big Title\r\n            &lt;/h3&gt;\r\n            &lt;p&gt;\r\n               Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n            &lt;/p&gt;');

-- --------------------------------------------------------

--
-- Structure de la table `system_languages`
--

CREATE TABLE IF NOT EXISTS `system_languages` (
  `language_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `flag_icon` varchar(50) NOT NULL,
  `dir` enum('LTR','RTL') NOT NULL,
  `default` enum('0','1') NOT NULL,
  `enabled` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `system_languages`
--

INSERT INTO `system_languages` (`language_id`, `code`, `title`, `flag_icon`, `dir`, `default`, `enabled`) VALUES
(1, 'en_US', 'English', 'us', 'LTR', '1', '1'),
(2, 'ar_EG', 'Arabic', 'sa', 'RTL', '0', '1'),
(3, 'fr_FR', 'Fran&ccedil;ais', 'fr', 'LTR', '0', '1'),
(4, 'es_ES', 'Espa&ntilde;ol', 'es', 'LTR', '0', '1'),
(5, 'pt_PT', 'Portugu&ecirc;s', 'pt', 'LTR', '0', '1'),
(6, 'de_DE', 'Deutsch', 'de', 'LTR', '0', '1'),
(7, 'tr_TR', 'T&uuml;rk&ccedil;e', 'tr', 'LTR', '0', '1'),
(8, 'nl_NL', 'Dutch', 'nl', 'LTR', '0', '1'),
(9, 'it_IT', 'Italiano', 'it', 'LTR', '0', '1'),
(10, 'ru_RU', 'Russian', 'ru', 'LTR', '0', '1');

-- --------------------------------------------------------

--
-- Structure de la table `system_options`
--

CREATE TABLE IF NOT EXISTS `system_options` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `system_live` enum('1','0') NOT NULL DEFAULT '1',
  `system_message` text NOT NULL,
  `system_title` varchar(255) NOT NULL DEFAULT 'Sngine',
  `system_description` text NOT NULL,
  `system_url` varchar(255) NOT NULL,
  `system_uploads_directory` varchar(255) NOT NULL,
  `system_domain` varchar(255) NOT NULL,
  `users_can_register` enum('1','0') NOT NULL DEFAULT '1',
  `social_login_enabled` enum('1','0') NOT NULL DEFAULT '0',
  `facebook_login_enabled` enum('1','0') NOT NULL DEFAULT '0',
  `facebook_appid` varchar(255) DEFAULT NULL,
  `facebook_secret` varchar(255) DEFAULT NULL,
  `twitter_login_enabled` enum('1','0') NOT NULL DEFAULT '0',
  `twitter_appid` varchar(255) DEFAULT NULL,
  `twitter_secret` varchar(255) DEFAULT NULL,
  `google_login_enabled` enum('1','0') NOT NULL DEFAULT '0',
  `google_appid` varchar(255) DEFAULT NULL,
  `google_secret` varchar(255) DEFAULT NULL,
  `reCAPTCHA_enabled` enum('1','0') NOT NULL DEFAULT '0',
  `reCAPTCHA_site_key` varchar(255) NOT NULL,
  `reCAPTCHA_secret_key` varchar(255) NOT NULL,
  `email_send_activation` enum('1','0') NOT NULL DEFAULT '1',
  `email_smtp_enabled` enum('1','0') NOT NULL DEFAULT '0',
  `email_smtp_authentication` enum('1','0') NOT NULL DEFAULT '1',
  `email_smtp_server` varchar(255) NOT NULL,
  `email_smtp_port` varchar(255) NOT NULL,
  `email_smtp_username` varchar(255) NOT NULL,
  `email_smtp_password` varchar(255) NOT NULL,
  `min_results` int(10) NOT NULL DEFAULT '5',
  `min_results_even` int(10) NOT NULL DEFAULT '6',
  `max_results` int(10) NOT NULL DEFAULT '10',
  `games_enabled` enum('1','0') NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `system_options`
--

INSERT INTO `system_options` (`ID`, `system_live`, `system_message`, `system_title`, `system_description`, `system_url`, `system_uploads_directory`, `system_domain`, `users_can_register`, `social_login_enabled`, `facebook_login_enabled`, `facebook_appid`, `facebook_secret`, `twitter_login_enabled`, `twitter_appid`, `twitter_secret`, `google_login_enabled`, `google_appid`, `google_secret`, `reCAPTCHA_enabled`, `reCAPTCHA_site_key`, `reCAPTCHA_secret_key`, `email_send_activation`, `email_smtp_enabled`, `email_smtp_authentication`, `email_smtp_server`, `email_smtp_port`, `email_smtp_username`, `email_smtp_password`, `min_results`, `min_results_even`, `max_results`, `games_enabled`) VALUES
(1, '1', 'We are updating the system please come later!', 'Sngine', '', 'http://codechat.dev', 'content/uploads', 'codechat.dev', '1', '0', '0', '', '', '0', '', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '', 5, 6, 10, '1');

-- --------------------------------------------------------

--
-- Structure de la table `system_themes`
--

CREATE TABLE IF NOT EXISTS `system_themes` (
  `theme_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `default` enum('0','1') NOT NULL,
  PRIMARY KEY (`theme_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=3 ;

--
-- Contenu de la table `system_themes`
--

INSERT INTO `system_themes` (`theme_id`, `name`, `default`) VALUES
(1, 'default', '1');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_group` tinyint(1) unsigned NOT NULL DEFAULT '3',
  `user_name` varchar(64) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_token` varchar(64) NOT NULL,
  `user_password` varchar(64) NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `user_gender` enum('M','F') NOT NULL,
  `user_picture` varchar(255) NOT NULL,
  `user_cover` varchar(255) NOT NULL,
  `user_work_title` varchar(50) NOT NULL,
  `user_work_place` varchar(50) NOT NULL,
  `user_current_city` varchar(50) NOT NULL,
  `user_hometown` varchar(50) NOT NULL,
  `user_edu_major` varchar(50) DEFAULT NULL,
  `user_edu_school` varchar(50) NOT NULL,
  `user_edu_class` varchar(50) NOT NULL,
  `user_birthdate` date DEFAULT NULL,
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_last_login` datetime NOT NULL,
  `user_privacy_birthdate` enum('friends','public') NOT NULL DEFAULT 'public',
  `user_privacy_work` enum('friends','public') NOT NULL DEFAULT 'public',
  `user_privacy_location` enum('friends','public') NOT NULL DEFAULT 'public',
  `user_privacy_education` enum('friends','public') NOT NULL DEFAULT 'public',
  `user_privacy_friends` enum('me','friends','public') NOT NULL DEFAULT 'public',
  `user_privacy_pages` enum('me','friends','public') NOT NULL DEFAULT 'public',
  `user_privacy_groups` enum('me','friends','public') NOT NULL DEFAULT 'public',
  `user_activation_key` varchar(64) NOT NULL,
  `user_activated` enum('0','1') NOT NULL DEFAULT '0',
  `user_verified` enum('0','1') NOT NULL DEFAULT '0',
  `user_reseted` enum('0','1') NOT NULL DEFAULT '0',
  `user_reset_key` varchar(64) NOT NULL,
  `user_blocked` enum('0','1') NOT NULL DEFAULT '0',
  `user_ip` varchar(64) NOT NULL,
  `user_chat_enabled` enum('0','1') NOT NULL DEFAULT '1',
  `user_live_requests_counter` int(10) NOT NULL DEFAULT '0',
  `user_live_requests_lastid` int(10) NOT NULL DEFAULT '0',
  `user_live_messages_counter` int(10) NOT NULL DEFAULT '0',
  `user_live_messages_lastid` int(10) NOT NULL DEFAULT '0',
  `user_live_notifications_counter` int(10) NOT NULL DEFAULT '0',
  `user_live_notifications_lastid` int(10) NOT NULL DEFAULT '0',
  `facebook_connected` enum('0','1') NOT NULL DEFAULT '0',
  `facebook_id` varchar(255) DEFAULT NULL,
  `twitter_connected` enum('0','1') NOT NULL DEFAULT '0',
  `twitter_id` varchar(255) DEFAULT NULL,
  `google_connected` enum('0','1') NOT NULL DEFAULT '0',
  `google_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`user_name`),
  UNIQUE KEY `user_email` (`user_email`),
  UNIQUE KEY `user_token` (`user_token`),
  UNIQUE KEY `facebook_id` (`facebook_id`),
  UNIQUE KEY `twitter_id` (`twitter_id`),
  UNIQUE KEY `google_id` (`google_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`user_id`, `user_group`, `user_name`, `user_email`, `user_token`, `user_password`, `user_fullname`, `user_gender`, `user_picture`, `user_cover`, `user_work_title`, `user_work_place`, `user_current_city`, `user_hometown`, `user_edu_major`, `user_edu_school`, `user_edu_class`, `user_birthdate`, `user_registered`, `user_last_login`, `user_privacy_birthdate`, `user_privacy_work`, `user_privacy_location`, `user_privacy_education`, `user_privacy_friends`, `user_privacy_pages`, `user_privacy_groups`, `user_activation_key`, `user_activated`, `user_verified`, `user_reseted`, `user_reset_key`, `user_blocked`, `user_ip`, `user_chat_enabled`, `user_live_requests_counter`, `user_live_requests_lastid`, `user_live_messages_counter`, `user_live_messages_lastid`, `user_live_notifications_counter`, `user_live_notifications_lastid`, `facebook_connected`, `facebook_id`, `twitter_connected`, `twitter_id`, `google_connected`, `google_id`) VALUES
(1, 1, 'Admin', 'ntdat.tb@gmail.com', '1be3f360f587fd704cfa23a1eefb3011', '0bf04cff00b94c2c860c98a3d637dcd8', 'Admin', 'M', '', '', '', '', '', '', NULL, '', '', NULL, '2016-12-07 10:05:33', '2016-12-13 03:50:09', 'public', 'public', 'public', 'public', 'public', 'public', 'public', '', '1', '1', '0', '', '0', '127.0.0.1', '1', 0, 0, 0, 5, 0, 0, '0', NULL, '0', NULL, '0', NULL),
(2, 3, 'nnkhanh', 'nguyenkhanh7493@gmail.com', '63905918c33504069f3c7ee40b75b813', '668f5075cde816e95043d5d82d9e0004', 'Nguyễn Như Kh&aacute;nh', 'M', '', '', '', '', '', '', NULL, '', '', NULL, '2016-12-07 10:11:24', '2016-12-13 03:43:51', 'public', 'public', 'public', 'public', 'public', 'public', 'public', '8c986d58b92f76b49775dddf3df836ee', '0', '0', '0', '', '0', '127.0.0.1', '1', 0, 0, 0, 5, 0, 0, '0', NULL, '0', NULL, '0', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `users_blocks`
--

CREATE TABLE IF NOT EXISTS `users_blocks` (
  `user_id` int(10) unsigned NOT NULL,
  `blocked_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `user_id_blocked_id` (`user_id`,`blocked_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

-- --------------------------------------------------------

--
-- Structure de la table `users_online`
--

CREATE TABLE IF NOT EXISTS `users_online` (
  `user_id` int(10) unsigned NOT NULL,
  `last_seen` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `UserID` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Contenu de la table `users_online`
--

INSERT INTO `users_online` (`user_id`, `last_seen`) VALUES
(1, '2016-12-13 04:24:37');

-- --------------------------------------------------------

--
-- Structure de la table `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `widget_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `code` text NOT NULL,
  PRIMARY KEY (`widget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
